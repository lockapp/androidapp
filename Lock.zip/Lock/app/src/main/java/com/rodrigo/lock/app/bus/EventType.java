package com.rodrigo.lock.app.bus;

/**
 * Created by Rodrigo on 20/12/2016.
 */

public enum EventType {
    EMPEZANDO_ANIADIR_ARCHIVOS,
    TERMINO_ANIADIR_ARCHICOS,
    EMPEZANDO_EXTRAER_ARCHIVOS,
    TERMINO_EXTRAER_ARCHICOS;

}
