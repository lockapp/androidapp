package com.rodrigo.lock.app.data.Clases;

/**
 * Created by Rodrigo on 19/11/2016.
 */

public class Vault {
    String fullPath;
    String name;
    String size;


    public String getFullPath() {
        return fullPath;
    }

    public void setFullPath(String fullPath) {
        this.fullPath = fullPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
