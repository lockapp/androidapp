package com.rodrigo.lock.app.mvp;

/**
 * Created by Rodrigo on 19/11/2016.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);

}
