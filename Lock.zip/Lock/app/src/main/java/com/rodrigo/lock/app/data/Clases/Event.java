package com.rodrigo.lock.app.data.Clases;

/**
 * Created by Rodrigo on 20/12/2016.
 */

public class Event {
}
