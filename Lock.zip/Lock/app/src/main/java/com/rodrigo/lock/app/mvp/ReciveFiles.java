package com.rodrigo.lock.app.mvp;

/**
 * Created by Rodrigo on 03/12/2016.
 */

public class ReciveFiles {
}
